import modin.pandas as pd
from modin.utils import to_pandas

import urllib.parse as urlparse 
from urllib.parse import parse_qs
import numpy as np


class traffic_analyser(object):
	"""
	INPUTS:
		- filepath: location of file in <s3??>
			- Type: String

		- long_report: (optional) Flag to generate long report for detailed analysis.
			- Type: Bool | Default: True

	OUTPUTS:

	METHODS:
		- 

	"""
	def __init__(self, filepath, long_report = False):
		self.filepath = filepath
		self.long_report_flag = long_report

		# MISC CONFIG
		self.long_report_columns = ['ip', 'referrer_host', 'potential_search_term', 'category', 'product_name', 'number_of_items', 'total_revenue']


	def preprocess_product_list(self, df):
		"""
		<DOCSTRING>
		"""
		df = df.copy()
		# Fill missing product_lists
		df['product_list'] = df['product_list'].fillna(';'*5)

		# If multiple products are involved, split them in seperate rows
		df['product_list'] = df['product_list'].str.split(',')
		df = df.explode('product_list')

		# Split product_list details
		df['product_list'] = df['product_list'].str.split(';')
		df['product_list_len'] = df['product_list'].str.len()

		# Mitigate missing merchandizing_evar
		df['product_list'] = df['product_list'].apply(lambda x: [*x, *['']*(6-len(x))] if len(x) < 6 else x)
		df['product_list_len'] = df['product_list'].str.len()

		# Parse product list and merge with main df
		product_list_explode_columns = ['category', 'product_name', 'number_of_items', 'total_revenue', 'custom_events', 'merchandizing_eVar']

		product_list_explode_df = pd.DataFrame(df.product_list.tolist(), index = df.index)
		product_list_explode_df.columns = product_list_explode_columns
		df = pd.merge(df, product_list_explode_df, right_index=True, left_index=True)

		return df

	def get_revenue_search_engine_keyword(self, df):
		"""
		"""
		groupby_columns = ['ip']
		df.sort_values('date_time', inplace = True)
		# Convert to pandas 
		df = to_pandas(df) # parallelization for each group doesnt gain a significant boost because the cost of the groupby component is too high.

		# Get revenue and referrer info for each session in one dataframe
		revenue_df = pandas_df.groupby(groupby_columns).apply(lambda grp: get_revenue(grp)).reset_index()
		referrer_df = pandas_df.groupby(groupby_columns).apply(lambda grp: get_search_engine_keyword(grp)).reset_index()

		op_df = referrer_df.merge(revenue_df, on=groupby_columns, how = 'left') # Left merge because we can have search terms which have no revenue. 
																   # Business might be interested in these trends
		op_df.fillna({'total_revenue':0, 'number_of_items':0}, inplace=True)

		# Manual datatype override
		op_df['number_of_items'] = op_df['number_of_items'].astype('int')
		op_df['total_revenue'] = op_df['total_revenue'].astype('int')
		return pd.DataFrame(op_df)


	def generate_summary_report(self, df):
		"""
		"""
		return df.groupby(['referrer_host', 'potential_search_term']).agg({'number_of_items':'sum','total_revenue':'sum'}).reset_index()

	def generate_long_report(self, df):
		"""
		"""
		return df[[self.long_report_columns]]


	def get_search_term(url):
		"""
		Try extracting search term from each URL

		"""
		search_term_keys = ('q','p','k')  #This list will have to evolve over time to improve accuracy of discovering keywords

		keyword_list= []
		query_string = urlparse.urlparse(url) 

		for param, value in parse_qs(query_string.query).items():
		  if param in search_term_keys:
			  keyword_list.append(value[0])

		if len(keyword_list) < 1:
		return np.NaN
		return keyword_list[0]

	def get_search_engine(url):
		"""
		Get the referrer domain
		"""
		se = []
		query_string = urlparse.urlparse(url) 
		se.append(query_string.netloc)

		if len(se) < 1:
		return np.NaN
		return se[0]


	def get_revenue(df):
		output_columns = ['geo_city', 'geo_region', 'geo_country', 'category', 'product_name', 'number_of_items', 'total_revenue']
		return df[df.event_list == 1][output_columns]

	def get_search_engine_keyword(df):
		df.sort_values('date_time', inplace = True)

		keywords = df['potential_search_term'].unique()
		hosts = df['referrer_host'].unique()

		return df[~df.potential_search_term.isna()][['potential_search_term', 'referrer_host']].iloc[0]


	def process_file(self):
		"""
		"""
		df = pd.read_csv(f"s3://website-traffic-artifacts/input",delimiter = '\t')
		processed_df = self.preprocess_product_list(df)

		processed_df['potential_search_term'] = processed_df['referrer'].apply(lambda x: get_search_term(str(x)), axis=1)
		processed_df['referrer_host'] = processed_df['referrer'].apply(lambda x: get_search_engine(str(x)), axis=1)

		dilated_df = self.get_revenue_search_engine_keyword(processed_df)

		if self.long_report_flag:
			output_df = self.generate_long_report(dilated_df)
		else:
			output_df = self.generate_summary_report(dilated_df)

		return output_df

